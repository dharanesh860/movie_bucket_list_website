# Deployment Guide for Movie Bucket List

This project is optimized for deployment on **Vercel** or **Netlify**. Both platforms offer excellent free tiers perfect for personal projects.

## Prerequisites

1.  **OMDb API Key**: You will need your API Key (`VITE_OMDB_API_KEY`).
2.  **GitHub Repository**: Push this code to a new GitHub repository.

## Option 1: Deploy to Vercel (Recommended)

1.  Go to [Vercel](https://vercel.com) and sign up/login.
2.  Click **"Add New..."** > **"Project"**.
3.  Import your GitHub repository.
4.  In the **Configure Project** screen:
    *   **Framework Preset**: Vite (should be auto-detected).
    *   **Root Directory**: `./` (default).
    *   **Environment Variables**:
        *   Key: `VITE_OMDB_API_KEY`
        *   Value: `your_actual_api_key_here`
5.  Click **Deploy**.

*Note: A `vercel.json` file has been included to handle Single Page Application (SPA) routing automatically.*

## Option 2: Deploy to Netlify

1.  Go to [Netlify](https://netlify.com) and sign up/login.
2.  Click **"Add new site"** > **"Import from an existing project"**.
3.  Connect to GitHub and select your repository.
4.  In the **Build settings** screen:
    *   **Build command**: `npm run build`
    *   **Publish directory**: `dist`
5.  Click **"Show advanced"** (or go to "Site settings" -> "Environment variables" later) and add:
    *   Key: `VITE_OMDB_API_KEY`
    *   Value: `your_actual_api_key_here`
6.  Click **Deploy site**.

*Note: A `netlify.toml` file has been included to handle SPA routing redirects automatically.*

## Mobile Verification

The application is fully responsive. Before sharing, verification on a mobile device is recommended:
1.  **Navigation**: Ensure the bottom navigation bar appears on mobile screens (< 768px).
2.  **Scrolling**: Check that the 'Add Movie' floating button (FAB) does not overlap with the bottom navigation.
3.  **Touch Targets**: Verify that all buttons, especially in the Profile section, are easily tappable.

## Build Verification

The project has been pre-validated with a local build check:
- Build Command: `npm run build`
- Status: **Success**
- Output Directory: `dist/`

## Environment Configuration

To ensure the application functions correctly in production, you must configure the following Environment Variables in your deployment platform (Vercel/Netlify):

| Variable            | Description                                      | Required? |
| ------------------- | ------------------------------------------------ | :-------: |
| `VITE_OMDB_API_KEY` | Your API Key from [OMDb](https://www.omdbapi.com/apikey.aspx) |    ✅     |
| `VITE_TMDB_API_KEY` | Your API Key from [TMDB](https://www.themoviedb.org/) | Optional  |

*Note: Do NOT commit your `.env` file containing actual keys to GitHub. Use the variables dashboard provided by Vercel or Netlify.*
