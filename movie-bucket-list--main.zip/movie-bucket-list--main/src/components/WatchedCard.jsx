import React from 'react';
import { motion } from 'framer-motion';
import { Star, RotateCcw, PenTool, Calendar } from 'lucide-react';
import { handleImageError } from '../utils/imageUtils';
import './WatchedCard.css';

const WatchedCard = ({ movie, onReWatch, onAddNote }) => {
    return (
        <motion.div
            className="watched-card"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            whileHover={{ y: -5 }}
        >
            <div className="watched-poster">
                <img
                    src={movie.poster}
                    alt={movie.title}
                    onError={handleImageError}
                    loading="lazy"
                />
                <div className="watched-poster-overlay">
                    <button className="btn-rewatch" onClick={() => onReWatch(movie.id)}>
                        <RotateCcw size={16} /> Re-watch
                    </button>
                </div>
            </div>

            <div className="watched-content">
                <div className="watched-header">
                    <h3 className="watched-title">{movie.title}</h3>
                    <div className="user-rating">
                        {[...Array(5)].map((_, i) => (
                            <Star
                                key={i}
                                size={12}
                                fill={i < (movie.userRating || 0) ? "#e50914" : "none"}
                                stroke={i < (movie.userRating || 0) ? "#e50914" : "#555"}
                            />
                        ))}
                    </div>
                </div>

                <div className="watched-meta">
                    <div className="watched-date">
                        <Calendar size={12} />
                        <span>{movie.watchedDate || "Recently"}</span>
                    </div>
                </div>

                <button className="btn-add-note" onClick={() => onAddNote(movie)}>
                    <PenTool size={12} /> Add Note
                </button>
            </div>
        </motion.div>
    );
};

export default WatchedCard;
