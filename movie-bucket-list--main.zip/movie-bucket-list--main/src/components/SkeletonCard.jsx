import React from 'react';
import './Skeleton.css';
import './MovieCard.css'; // Re-use movie card dimensions

const SkeletonCard = ({ detailed }) => {
    return (
        <div className={`movie-card skeleton-card-wrapper ${detailed ? 'skeleton-detailed' : ''}`}>
            <div className="card-poster">
                <div className="skeleton skeleton-poster"></div>
            </div>
            <div className="card-info" style={{ marginTop: '12px', padding: '0 4px', opacity: 1, transform: 'none' }}>
                <div className="skeleton" style={{ height: '16px', marginBottom: '8px', width: '85%' }}></div>
                <div className="skeleton" style={{ height: '12px', width: '40%' }}></div>
            </div>
        </div>
    );
};

export default SkeletonCard;
