import React from 'react';
import { motion } from 'framer-motion';
import { Film, Search } from 'lucide-react';
import './EmptyState.css';

const EmptyState = ({
    title = "It's quiet here...",
    message = "Start your cinematic journey by adding movies to your list.",
    actionLabel = "Search Movies",
    onAction
}) => {
    return (
        <motion.div
            className="empty-state-container"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
        >
            <div className="empty-state-icon-wrapper">
                <Film size={48} className="empty-icon-main" />
                <Search size={24} className="empty-icon-secondary" />
            </div>

            <h2 className="empty-title">{title}</h2>
            <p className="empty-message">{message}</p>

            {onAction && (
                <button className="empty-cta-btn" onClick={onAction}>
                    {actionLabel}
                </button>
            )}
        </motion.div>
    );
};

export default EmptyState;
