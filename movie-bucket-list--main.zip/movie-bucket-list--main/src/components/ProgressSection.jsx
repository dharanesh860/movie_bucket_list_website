import React from 'react';
import { motion } from 'framer-motion';
import './ProgressSection.css';

const ProgressSection = ({ movies }) => {
    const total = movies.length;
    const watched = movies.filter(m => m.status === 'Watched').length;
    const percentage = total === 0 ? 0 : Math.round((watched / total) * 100);

    return (
        <motion.div
            className="progress-section container"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
        >
            <div className="progress-header">
                <h3 className="progress-title">My Journey</h3>
                <span className="progress-stats">{watched} / {total} Watched</span>
            </div>

            <div className="progress-track">
                <motion.div
                    className="progress-fill"
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    transition={{ duration: 1.5, ease: "easeInOut", delay: 0.8 }}
                >
                    <div className="progress-glow"></div>
                </motion.div>
            </div>

            <div className="progress-footer">
                <span className="progress-percent">{percentage}% Completed</span>
                {percentage === 100 && <span className="progress-congrats">🎉 All caught up!</span>}
            </div>
        </motion.div>
    );
};
export default ProgressSection;
