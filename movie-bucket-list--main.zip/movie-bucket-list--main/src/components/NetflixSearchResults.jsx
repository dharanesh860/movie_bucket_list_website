import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Plus, Check } from 'lucide-react';
import { searchOmdbMovies } from '../services/omdb';
import { handleImageError } from '../utils/imageUtils';
import SkeletonCard from './SkeletonCard';
import './NetflixSearchResults.css';

const NetflixSearchResults = ({ onAddMovie, existingMovieIds = [], onMovieClick }) => {
    const [query, setQuery] = useState('');
    const [movies, setMovies] = useState([]);
    const [loading, setLoading] = useState(false);
    const [debouncedQuery, setDebouncedQuery] = useState(query);

    // Debounce search input
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedQuery(query);
        }, 500);
        return () => clearTimeout(handler);
    }, [query]);

    // Fetch movies when debounced query changes
    useEffect(() => {
        const fetchMovies = async () => {
            if (!debouncedQuery.trim()) {
                setMovies([]);
                return;
            }
            setLoading(true);
            const results = await searchOmdbMovies(debouncedQuery);
            setMovies(results);
            setLoading(false);
        };
        fetchMovies();
    }, [debouncedQuery]);

    const isAdded = (id) => existingMovieIds.includes(id);

    return (
        <section className="netflix-search-section">
            <div className="search-container">
                <div className="search-input-box">
                    <Search className="search-icon-large" />
                    <input
                        type="text"
                        className="netflix-search-input"
                        placeholder="Titles, people, genres..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                    />
                </div>
            </div>

            <div className="results-container">
                {loading ? (
                    <div className="loading-grid">
                        {[...Array(8)].map((_, i) => (
                            <div key={i} className="skeleton-wrapper">
                                <SkeletonCard detailed={true} />
                            </div>
                        ))}
                    </div>
                ) : (
                    <motion.div
                        className="movies-grid"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.5 }}
                    >
                        {movies.map((movie) => (
                            <motion.div
                                key={movie.imdbID || movie.id}
                                className="netflix-movie-card"
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                whileHover={{ scale: 1.05, zIndex: 10 }}
                                transition={{ duration: 0.3 }}
                                onClick={() => onMovieClick && onMovieClick(movie)}
                            >
                                <div className="poster-wrapper">
                                    <img
                                        src={movie.poster}
                                        alt={movie.title}
                                        loading="lazy"
                                        onError={handleImageError}
                                    />
                                    <div className="hover-overlay">
                                        <button
                                            className={`add-btn ${isAdded(movie.id) ? 'added' : ''}`}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                if (!isAdded(movie.id) && onAddMovie) onAddMovie(movie);
                                            }}
                                            disabled={isAdded(movie.id)}
                                        >
                                            {isAdded(movie.id) ? (
                                                <>
                                                    <Check size={16} /> Added
                                                </>
                                            ) : (
                                                <>
                                                    <Plus size={16} /> Add to Bucket List
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </div>
                                <div className="movie-meta">
                                    <h3 className="movie-title">{movie.title}</h3>
                                    <span className="movie-year">{movie.year}</span>
                                </div>
                            </motion.div>
                        ))}
                    </motion.div>
                )}

                {!loading && movies.length === 0 && debouncedQuery && (
                    <div className="no-results">
                        <p>No movies found for "{debouncedQuery}"</p>
                    </div>
                )}
            </div>
        </section>
    );
};

export default NetflixSearchResults;
