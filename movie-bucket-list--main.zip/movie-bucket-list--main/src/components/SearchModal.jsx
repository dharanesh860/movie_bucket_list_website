import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, Plus, Check } from 'lucide-react';
import { searchMovies, getTrendingMovies } from '../services/tmdb';
import './SearchModal.css';

const SearchModal = ({ isOpen, onClose, onAddMovie, existingMovieIds, onMovieClick }) => {
    const [query, setQuery] = useState('');
    const [results, setResults] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [trending, setTrending] = useState([]);

    // Load trending on mount
    useEffect(() => {
        if (isOpen && trending.length === 0) {
            getTrendingMovies().then(setTrending);
        }
    }, [isOpen]);

    // Debounced search
    useEffect(() => {
        const timer = setTimeout(() => {
            if (query.trim()) {
                handleSearch();
            } else {
                setResults([]);
            }
        }, 500);
        return () => clearTimeout(timer);
    }, [query]);

    const handleSearch = async () => {
        setIsLoading(true);
        const data = await searchMovies(query);
        setResults(data);
        setIsLoading(false);
    };

    const isAdded = (id) => existingMovieIds.includes(id);

    const displayMovies = query ? results : trending;
    const sectionTitle = query ? (results.length ? 'Search Results' : 'No results found') : 'Trending Now';

    if (!isOpen) return null;

    return (
        <AnimatePresence>
            <motion.div
                className="search-modal-overlay"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={onClose}
            >
                <motion.div
                    className="search-modal-container"
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: 50, opacity: 0 }}
                    onClick={e => e.stopPropagation()}
                >
                    <div className="search-header">
                        <div className="search-input-wrapper">
                            <Search className="search-icon" size={24} />
                            <input
                                type="text"
                                placeholder="Search movies to add..."
                                value={query}
                                onChange={e => setQuery(e.target.value)}
                                autoFocus
                            />
                            {query && (
                                <button className="clear-btn" onClick={() => setQuery('')}>
                                    <X size={20} />
                                </button>
                            )}
                        </div>
                        <button className="close-btn" onClick={onClose}>Close</button>
                    </div>

                    <div className="search-body">
                        <h3 className="section-title">{sectionTitle}</h3>

                        {isLoading ? (
                            <div className="loading-spinner"></div>
                        ) : (
                            <div className="search-grid">
                                {displayMovies.map((movie, index) => (
                                    <motion.div
                                        key={movie.id}
                                        className="search-card"
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: index * 0.05 }}
                                        onClick={() => onMovieClick && onMovieClick(movie)}
                                    >
                                        <div className="search-poster">
                                            <img src={movie.poster} alt={movie.title} loading="lazy" />
                                            <div className="search-card-overlay">
                                                <button
                                                    className={`btn-add-result ${isAdded(movie.id) ? 'added' : ''}`}
                                                    title={isAdded(movie.id) ? "Added to Bucket List" : "Add to My Bucket List"}
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        !isAdded(movie.id) && onAddMovie(movie);
                                                    }}
                                                    disabled={isAdded(movie.id)}
                                                >
                                                    {isAdded(movie.id) ? <Check size={20} /> : <Plus size={20} />}
                                                </button>
                                            </div>
                                        </div>
                                        <div className="search-info">
                                            <h4>{movie.title}</h4>
                                            <span>{movie.year}</span>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        )}

                        {!API_KEY_EXISTS() && (
                            <div className="api-warning">
                                Note: Add VITE_TMDB_API_KEY to .env to enable real search.
                            </div>
                        )}
                    </div>
                </motion.div>
            </motion.div>
        </AnimatePresence>
    );
};

// Helper to check for key without exposing it
const API_KEY_EXISTS = () => !!import.meta.env.VITE_TMDB_API_KEY;

export default SearchModal;
