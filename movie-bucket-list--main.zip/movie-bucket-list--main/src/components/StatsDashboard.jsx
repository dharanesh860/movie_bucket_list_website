import React from 'react';
import { motion } from 'framer-motion';
import { Film, CheckCircle, Clock, BarChart2 } from 'lucide-react';
import './StatsDashboard.css';

const StatCard = ({ title, value, icon: Icon, delay }) => {
    return (
        <motion.div
            className="stat-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
        >
            <div className="stat-icon-bg">
                <Icon size={24} />
            </div>
            <div className="stat-info">
                <span className="stat-value">{value}</span>
                <span className="stat-label">{title}</span>
            </div>
        </motion.div>
    );
};

const CircularProgress = ({ progress }) => {
    const radius = 45;
    const circleLength = 2 * Math.PI * radius;

    return (
        <div className="circular-chart">
            <svg viewBox="0 0 100 100" className="circular-svg">
                <circle
                    cx="50" cy="50" r={radius}
                    className="circle-bg"
                />
                <motion.circle
                    cx="50" cy="50" r={radius}
                    className="circle-progress"
                    initial={{ strokeDasharray: circleLength, strokeDashoffset: circleLength }}
                    animate={{ strokeDashoffset: circleLength - (progress / 100) * circleLength }}
                    transition={{ duration: 1.5, ease: "easeOut", delay: 0.5 }}
                />
            </svg>
            <div className="percentage-display">
                <span className="percent-value">{progress}%</span>
                <span className="percent-label">Watched</span>
            </div>
        </div>
    );
};

const ActivityChart = () => {
    // Mock data for the last 6 months
    const data = [
        { month: 'Sep', count: 2 },
        { month: 'Oct', count: 4 },
        { month: 'Nov', count: 3 },
        { month: 'Dec', count: 6 },
        { month: 'Jan', count: 5 },
        { month: 'Feb', count: 3 }
    ];

    const max = Math.max(...data.map(d => d.count));

    return (
        <div className="activity-chart">
            <div className="chart-header">
                <h4><BarChart2 size={16} /> Monthly Activity</h4>
            </div>
            <div className="chart-bars">
                {data.map((item, index) => (
                    <div key={item.month} className="bar-group">
                        <div className="bar-track">
                            <motion.div
                                className="bar-fill"
                                initial={{ height: 0 }}
                                animate={{ height: `${(item.count / max) * 100}%` }}
                                transition={{ duration: 1, delay: 0.5 + (index * 0.1) }}
                            />
                            <div className="bar-tooltip">{item.count} movies</div>
                        </div>
                        <span className="bar-label">{item.month}</span>
                    </div>
                ))}
            </div>
        </div>
    );
};

// Skeleton Components
const StatSkeleton = () => (
    <div className="stat-card skeleton-card">
        <div className="skeleton" style={{ width: '40px', height: '40px', borderRadius: '50%', marginBottom: '10px' }}></div>
        <div className="skeleton" style={{ width: '30px', height: '28px', marginBottom: '4px' }}></div>
        <div className="skeleton" style={{ width: '60px', height: '14px' }}></div>
    </div>
);

const ChartSkeleton = () => (
    <div className="chart-card skeleton-card" style={{ height: '250px', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <div className="skeleton" style={{ width: '150px', height: '24px' }}></div>
        <div className="skeleton" style={{ flexGrow: 1, width: '100%', borderRadius: '4px' }}></div>
    </div>
);

const StatsDashboard = ({ movies, loading }) => {
    const total = movies.length;
    const watched = movies.filter(m => m.status === 'Watched').length;
    const pending = total - watched;
    const percentage = total === 0 ? 0 : Math.round((watched / total) * 100);

    if (loading) {
        return (
            <div className="stats-dashboard">
                <div className="stats-grid-row">
                    <StatSkeleton />
                    <StatSkeleton />
                    <StatSkeleton />
                </div>
                <div className="charts-grid-row">
                    <ChartSkeleton />
                    <ChartSkeleton />
                </div>
            </div>
        );
    }

    return (
        <div className="stats-dashboard">
            {/* Top Cards Row */}
            <div className="stats-grid-row">
                <StatCard
                    title="Total Added"
                    value={total}
                    icon={Film}
                    delay={0.1}
                />
                <StatCard
                    title="Watched"
                    value={watched}
                    icon={CheckCircle}
                    delay={0.2}
                />
                <StatCard
                    title="Remaining"
                    value={pending}
                    icon={Clock}
                    delay={0.3}
                />
            </div>

            {/* Charts Row */}
            <div className="charts-grid-row">
                <motion.div
                    className="chart-card overview-card"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 }}
                >
                    <h3 className="dashboard-subtitle">Completion Status</h3>
                    <div className="progress-flex">
                        <CircularProgress progress={percentage} />
                        <div className="progress-details">
                            <p>You have completed <strong>{percentage}%</strong> of your list.</p>
                            <p className="sub-detail">Keep watching to reach your goal!</p>
                        </div>
                    </div>
                </motion.div>

                <motion.div
                    className="chart-card activity-card"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 }}
                >
                    <ActivityChart />
                </motion.div>
            </div>
        </div>
    );
};

export default StatsDashboard;
