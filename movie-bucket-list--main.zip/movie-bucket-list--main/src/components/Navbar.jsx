import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { User, Menu, X, Home, List, CheckSquare, BarChart2 } from 'lucide-react';
import { useUser } from '../context/UserContext';
import './Navbar.css';

const Navbar = () => {
    const [scrolled, setScrolled] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const location = useLocation();
    const { user } = useUser();

    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 50) {
                setScrolled(true);
            } else {
                setScrolled(false);
            }
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const navLinks = [
        { name: 'Home', path: '/', icon: <Home size={20} /> },
        { name: 'List', path: '/list', icon: <List size={20} /> },
        { name: 'Watched', path: '/watched', icon: <CheckSquare size={20} /> },
        { name: 'Stats', path: '/stats', icon: <BarChart2 size={20} /> },
    ];

    return (
        <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
            <div className="navbar-container">
                <Link to="/" className="navbar-logo">
                    MovieBucket
                </Link>

                <div className="mobile-menu-btn" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                    {isMenuOpen ? <X /> : <Menu />}
                </div>

                <div className={`navbar-links ${isMenuOpen ? 'active' : ''}`}>
                    {navLinks.map((link) => (
                        <Link
                            key={link.name}
                            to={link.path}
                            className={`nav-link ${location.pathname === link.path ? 'active' : ''}`}
                            onClick={() => setIsMenuOpen(false)}
                        >
                            {link.icon}
                            <span>{link.name}</span>
                        </Link>
                    ))}
                </div>

                <div className="navbar-right">
                    <Link to="/profile" className="profile-icon">
                        {user.avatar ? (
                            user.avatar.startsWith('data:') ? (
                                <img
                                    src={user.avatar}
                                    alt="Profile"
                                    style={{ width: '24px', height: '24px', borderRadius: '50%', objectFit: 'cover' }}
                                />
                            ) : (
                                <div
                                    style={{
                                        width: '24px',
                                        height: '24px',
                                        borderRadius: '50%',
                                        background: user.avatar,
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center'
                                    }}
                                >
                                    <User size={14} color="white" />
                                </div>
                            )
                        ) : (
                            <User size={20} />
                        )}
                    </Link>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
