import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Star, CheckCircle, Plus, Play, Info, Trash2 } from 'lucide-react';
import { handleImageError } from '../utils/imageUtils';
import './MovieCard.css';
import './Skeleton.css';

const MovieCard = ({ movie, onClick, onToggleStatus, onRemove }) => {
    const isWatched = movie.status === 'Watched';
    const [isLoaded, setIsLoaded] = useState(false);

    const handleToggle = (e) => {
        e.stopPropagation();
        onToggleStatus(movie.id);
    };

    return (
        <motion.div
            className="movie-card"
            onClick={() => onClick(movie)}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            whileHover={{
                scale: 1.15,
                zIndex: 10,
                boxShadow: "0 10px 20px rgba(0,0,0,0.5)"
            }}
            transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        >
            <div className="card-poster">
                {!isLoaded && <div className="skeleton skeleton-poster"></div>}
                <img
                    src={movie.poster}
                    alt={movie.title}
                    loading="lazy"
                    onLoad={() => setIsLoaded(true)}
                    onError={(e) => {
                        handleImageError(e);
                        setIsLoaded(true);
                    }}
                    className={isLoaded ? 'image-visible' : 'image-hidden'}
                />

                {/* Status Badge */}
                {(isWatched || movie.status === 'Want to Watch') && (
                    <div className={`status-badge ${isWatched ? 'watched' : 'pending'}`}>
                        {isWatched ? 'WATCHED' : 'TO WATCH'}
                    </div>
                )}

                {/* Overlay only visible on hover */}
                <div className="card-overlay">
                    <div className="card-actions">
                        <button className="btn-icon play" title="View Details">
                            <Play fill="currentColor" size={16} />
                        </button>
                        <button
                            className="btn-icon toggle"
                            title={isWatched ? "Mark as Unwatched" : "Mark as Watched"}
                            onClick={handleToggle}
                        >
                            {isWatched ? <CheckCircle size={18} /> : <Plus size={18} />}
                        </button>
                        <button className="btn-icon info" title="More Info">
                            <Info size={18} />
                        </button>
                        {onRemove && (
                            <button
                                className="btn-icon remove"
                                title="Remove from list"
                                onClick={(e) => { e.stopPropagation(); onRemove(movie.id); }}
                            >
                                <Trash2 size={18} />
                            </button>
                        )}
                    </div>

                    <div className="card-info">
                        <h3 className="card-title">{movie.title}</h3>
                        <div className="card-meta">
                            <div className="rating-badge">
                                <Star size={10} fill="currentColor" stroke="none" />
                                <span style={{ textShadow: '0 1px 2px rgba(0,0,0,0.8)' }}>{movie.rating}</span>
                            </div>
                            <span className="genres">{movie.genre.slice(0, 2).join(' • ')}</span>
                        </div>
                    </div>
                </div>
            </div>
        </motion.div>
    );
};

export default MovieCard;
