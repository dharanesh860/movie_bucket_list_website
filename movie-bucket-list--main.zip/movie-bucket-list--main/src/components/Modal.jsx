import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar, Star, CheckCircle, Plus, Clock } from 'lucide-react';
import { getMovieDetails } from '../services/tmdb';
import { getOmdbMovieDetails } from '../services/omdb';
import { handleImageError } from '../utils/imageUtils';
import './Modal.css';

const Modal = ({ movie: initialMovie, isOpen, onClose, onToggleStatus, onAddMovie, existingMovieIds = [] }) => {
    const [details, setDetails] = useState(null);
    const [loading, setLoading] = useState(false);

    // Reset details when movie opens
    useEffect(() => {
        if (initialMovie && isOpen) {
            setDetails(null);
            setLoading(true);

            // Determine source based on ID format
            const id = initialMovie.id;
            const isOmdb = typeof id === 'string' && id.startsWith('tt');
            const tmdbId = initialMovie.tmdb_id || (isOmdb ? null : id);

            const fetchDetails = async () => {
                let fetched = null;
                if (isOmdb) {
                    fetched = await getOmdbMovieDetails(id);
                } else if (tmdbId) {
                    fetched = await getMovieDetails(tmdbId);
                }

                if (fetched) {
                    setDetails(fetched);
                }
                setLoading(false);
            };

            fetchDetails();
        }

        if (isOpen) document.body.style.overflow = 'hidden';
        else document.body.style.overflow = 'unset';

        return () => { document.body.style.overflow = 'unset'; }
    }, [isOpen, initialMovie]);

    if (!initialMovie) return null;

    // Check if in library using ID
    const isInLibrary = existingMovieIds.includes(initialMovie.id);

    // Construct final movie object
    const movie = { ...initialMovie, ...details };

    const handleAdd = () => {
        if (onAddMovie) {
            onAddMovie({ ...movie, status: 'Want to Watch' });
            onClose();
        }
    };

    const handleMarkWatched = () => {
        if (isInLibrary) {
            // If already in library, toggle if needed or ensure it is watched
            if (onToggleStatus) onToggleStatus(movie.id);
        } else {
            // Add as watched
            if (onAddMovie) {
                onAddMovie({ ...movie, status: 'Watched' });
            }
        }
        onClose();
    };

    // Format runtime
    const formatRuntime = (min) => {
        if (!min) return 'N/A';
        const h = Math.floor(min / 60);
        const m = min % 60;
        return `${h}h ${m}m`;
    }

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="modal-overlay" onClick={onClose}>
                    <motion.div
                        className="modal-container"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.3, type: "spring", bounce: 0.2 }}
                        onClick={(e) => e.stopPropagation()}
                    >
                        <button className="modal-close-btn" onClick={onClose}>
                            <X size={24} />
                        </button>

                        <div className="modal-image-col">
                            <img src={movie.poster} alt={movie.title} onError={handleImageError} />
                            <div className="modal-poster-overlay"></div>
                        </div>

                        <div className="modal-info-col">
                            <h2 className="modal-title">{movie.title}</h2>
                            <div className="modal-meta-row">
                                <span className="meta-item"><Calendar size={16} /> {movie.year}</span>
                                <span className="meta-item highlight"><Star size={16} fill="currentColor" /> {movie.rating}</span>
                                <span className="meta-item duration"><Clock size={16} /> {formatRuntime(movie.runtime)}</span>
                            </div>

                            <div className="modal-genres">
                                {movie.genre?.map((g, i) => (
                                    <span key={i} className="genre-chip">{g}</span>
                                ))}
                            </div>

                            <div className="modal-description-box">
                                <p className="modal-description">
                                    {movie.description || movie.Plot || "No description available."}
                                </p>
                            </div>

                            <div className="modal-actions">
                                {!isInLibrary ? (
                                    <>
                                        <button className="btn-action primary" onClick={handleAdd}>
                                            <Plus size={20} /> Add to Bucket List
                                        </button>
                                        <button className="btn-action secondary" onClick={handleMarkWatched}>
                                            <CheckCircle size={20} /> Mark as Watched
                                        </button>
                                    </>
                                ) : (
                                    <button
                                        className={`btn-action ${movie.status === 'Watched' ? 'watched' : 'primary'}`}
                                        onClick={() => onToggleStatus(movie.id)}
                                    >
                                        {movie.status === 'Watched' ? (
                                            <><CheckCircle size={20} /> Watched</>
                                        ) : (
                                            <><CheckCircle size={20} /> Mark as Watched</>
                                        )}
                                    </button>
                                )}
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
};

export default Modal;
