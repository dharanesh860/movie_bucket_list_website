import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import MovieCard from './MovieCard';
import SkeletonCard from './SkeletonCard';
import './MovieRow.css';

const MovieRow = ({ title, movies, onMovieClick, onToggleStatus, loading, error, onRetry }) => {
    const rowRef = useRef(null);
    const [isMoved, setIsMoved] = useState(false);

    const handleClick = (direction) => {
        setIsMoved(true);
        if (rowRef.current) {
            const { scrollLeft, clientWidth } = rowRef.current;
            const scrollTo = direction === 'left' ? scrollLeft - clientWidth + 200 : scrollLeft + clientWidth - 200;
            rowRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
        }
    };

    if (error) {
        return (
            <div className="movie-row-container">
                <h2 className="movie-row-title">{title}</h2>
                <div className="error-message">
                    <p>Failed to load movies.</p>
                    {onRetry && <button onClick={onRetry} className="retry-btn">Retry</button>}
                </div>
            </div>
        );
    }

    if (loading) {
        return (
            <div className="movie-row-container">
                <h2 className="movie-row-title">{title}</h2>
                <div className="movie-row">
                    {[...Array(8)].map((_, i) => (
                        <div key={i} className="movie-row-item">
                            <SkeletonCard />
                        </div>
                    ))}
                </div>
            </div>
        );
    }

    if (!movies || movies.length === 0) return null;

    return (
        <div className="movie-row-container">
            <h2 className="movie-row-title">{title}</h2>

            <div className="movie-row-wrapper group">
                <div
                    className={`slider-arrow left ${!isMoved ? 'hidden' : ''}`}
                    onClick={() => handleClick('left')}
                >
                    <ChevronLeft className="arrow-icon" />
                </div>

                <div
                    className="movie-row"
                    ref={rowRef}
                >
                    {movies.map(movie => (
                        <div key={movie.imdbID || movie.id} className="movie-row-item">
                            <MovieCard
                                movie={movie}
                                onClick={onMovieClick}
                                onToggleStatus={onToggleStatus}
                            />
                        </div>
                    ))}
                </div>

                <div
                    className="slider-arrow right"
                    onClick={() => handleClick('right')}
                >
                    <ChevronRight className="arrow-icon" />
                </div>
            </div>
        </div>
    );
};

export default MovieRow;
