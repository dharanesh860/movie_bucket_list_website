import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Play } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { handleImageError } from '../utils/imageUtils';
import './Hero.css';

const Hero = ({ movies, loading }) => {
    const navigate = useNavigate();

    if (loading) {
        return (
            <div className="hero featured-hero" style={{ background: '#141414' }}>
                <div className="hero-gradient-overlay" style={{ background: 'linear-gradient(to top, #141414 10%, rgba(20,20,20,0.6) 50%, rgba(0,0,0,0.4) 100%)' }}></div>
                <div className="hero-content featured-content">
                    <div className="skeleton" style={{ height: '60px', width: '60%', maxWidth: '500px', marginBottom: '1.5rem', borderRadius: '4px' }}></div>
                    <div className="skeleton" style={{ height: '20px', width: '80%', maxWidth: '400px', marginBottom: '0.8rem', borderRadius: '4px' }}></div>
                    <div className="skeleton" style={{ height: '20px', width: '60%', maxWidth: '300px', marginBottom: '2rem', borderRadius: '4px' }}></div>
                    <div className="skeleton" style={{ height: '50px', width: '200px', borderRadius: '4px' }}></div>
                </div>
            </div>
        );
    }

    // If we have a single featured movie with a backdrop, use Cinematic Mode
    const featuredMovie = movies.length === 1 ? movies[0] : null;

    if (featuredMovie && featuredMovie.backdrop) {
        return (
            <div className="hero featured-hero" style={{ background: `url(${featuredMovie.backdrop}) no-repeat center center / cover` }}>
                <div className="hero-gradient-overlay" style={{ background: 'linear-gradient(to top, #141414 10%, rgba(20,20,20,0.6) 50%, rgba(0,0,0,0.4) 100%)' }}></div>
                <div className="hero-content featured-content">
                    <motion.h1
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="hero-title"
                        style={{ maxWidth: '800px', textShadow: '0 2px 10px rgba(0,0,0,0.8)' }}
                    >
                        {featuredMovie.title}
                    </motion.h1>

                    <motion.p
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.3 }}
                        className="hero-subtitle"
                        style={{ maxWidth: '600px', textShadow: '0 1px 4px rgba(0,0,0,0.8)', margin: '1rem auto' }}
                    >
                        {featuredMovie.description ? (featuredMovie.description.length > 200 ? featuredMovie.description.substring(0, 200) + '...' : featuredMovie.description) : "Track, watch, and remember."}
                    </motion.p>
                </div>
            </div>
        );
    }

    // Fallback: Collage Mode
    const collageImages = movies ? [...movies, ...movies, ...movies].slice(0, 12) : [];

    return (
        <div className="hero">
            <div className="hero-bg-collage">
                {collageImages.map((movie, index) => (
                    // eslint-disable-next-line
                    <div key={index} className="collage-item">
                        <img
                            src={movie.poster}
                            alt=""
                            onError={handleImageError}
                        />
                    </div>
                ))}
            </div>

            {/* Dark gradients for readability */}
            <div className="hero-gradient-overlay"></div>

            <div className="hero-content">
                <motion.h1
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 1.2, ease: "easeOut" }}
                    className="hero-title"
                >
                    Your Personal<br />Movie Bucket List
                </motion.h1>

                <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4, duration: 1 }}
                    className="hero-subtitle"
                >
                    Track, watch, and remember every movie.
                </motion.p>

                <motion.button
                    className="hero-cta"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6, duration: 0.8 }}
                    whileHover={{ scale: 1.05, backgroundColor: '#f40612' }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => navigate('/bucket-list')}
                >
                    <Play fill="currentColor" size={20} />
                    Explore My List
                </motion.button>
            </div>
        </div>
    );
};

export default Hero;
