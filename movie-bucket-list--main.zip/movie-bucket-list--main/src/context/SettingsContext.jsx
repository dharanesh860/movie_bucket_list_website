import React, { createContext, useContext, useState, useEffect } from 'react';

const SettingsContext = createContext();

const defaultSettings = {
    theme: 'dark',
    notifications: true,
    compactMode: false
};

export const SettingsProvider = ({ children }) => {
    // Check local storage or default
    const [settings, setSettings] = useState(() => {
        const saved = localStorage.getItem('appSettings');
        return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings;
    });

    useEffect(() => {
        // Apply theme to document element
        document.documentElement.setAttribute('data-theme', settings.theme);
        localStorage.setItem('appSettings', JSON.stringify(settings));
    }, [settings]);

    const updateSetting = (key, value) => {
        setSettings(prev => ({ ...prev, [key]: value }));
    };

    const toggleSetting = (key) => {
        setSettings(prev => {
            if (key === 'theme') {
                return { ...prev, theme: prev.theme === 'dark' ? 'light' : 'dark' };
            }
            return { ...prev, [key]: !prev[key] };
        });
    };

    return (
        <SettingsContext.Provider value={{
            settings,
            updateSetting,
            toggleSetting,
            isDark: settings.theme === 'dark'
        }}>
            {children}
        </SettingsContext.Provider>
    );
};

export const useSettings = () => {
    const context = useContext(SettingsContext);
    if (!context) {
        throw new Error('useSettings must be used within a SettingsProvider');
    }
    return context;
};
