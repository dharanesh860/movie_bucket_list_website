import React, { createContext, useContext, useState, useEffect } from 'react';

const UserContext = createContext();

const defaultGenres = [
    { id: 1, name: 'Sci-Fi' },
    { id: 2, name: 'Thriller' },
    { id: 3, name: 'Noir' }
];

export const UserProvider = ({ children }) => {
    // Initialize state from local storage or defaults
    const [user, setUser] = useState(() => {
        const savedUser = localStorage.getItem('userProfile');
        if (savedUser) return JSON.parse(savedUser);

        // Migration: Check for legacy keys
        const legacyName = localStorage.getItem('profileName');
        const legacyAvatar = localStorage.getItem('userAvatar');

        return {
            name: legacyName || 'Cinephile One',
            avatar: legacyAvatar || null,
            genres: defaultGenres
        };
    });

    // Persist to local storage whenever user object changes
    useEffect(() => {
        localStorage.setItem('userProfile', JSON.stringify(user));
    }, [user]);

    const updateName = (name) => {
        setUser(prev => ({ ...prev, name }));
    };

    const updateAvatar = (avatar) => {
        setUser(prev => ({ ...prev, avatar }));
    };

    const updateGenres = (genres) => {
        setUser(prev => ({ ...prev, genres }));
    };

    return (
        <UserContext.Provider value={{ user, updateName, updateAvatar, updateGenres }}>
            {children}
        </UserContext.Provider>
    );
};

export const useUser = () => {
    const context = useContext(UserContext);
    if (!context) {
        throw new Error('useUser must be used within a UserProvider');
    }
    return context;
};
