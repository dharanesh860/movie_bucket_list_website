export const movies = [
    {
        id: "tt1375666",
        imdbID: "tt1375666",
        title: "Inception",
        poster: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?q=80&w=800&auto=format&fit=crop",
        genre: ["Sci-Fi", "Action"],
        rating: 8.8,
        status: "Watched",
        year: 2010,
        description: "A thief who steals corporate secrets through the use of dream-sharing technology.",
        watchedDate: "2023-11-15",
        userRating: 5
    },
    {
        id: "tt0468569",
        imdbID: "tt0468569",
        title: "The Dark Knight",
        poster: "https://images.unsplash.com/photo-1478720568477-152d9b164e63?q=80&w=800&auto=format&fit=crop",
        genre: ["Action", "Crime"],
        rating: 9.0,
        status: "Watched",
        year: 2008,
        description: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham.",
        watchedDate: "2024-01-20",
        userRating: 5
    },
    {
        id: "tt0816692",
        imdbID: "tt0816692",
        title: "Interstellar",
        poster: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=800&auto=format&fit=crop",
        genre: ["Sci-Fi", "Drama"],
        rating: 8.6,
        status: "Want to Watch",
        year: 2014,
        description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival."
    },
    {
        id: "tt6751668",
        imdbID: "tt6751668",
        title: "Parasite",
        poster: "https://images.unsplash.com/photo-1596727147705-54a9d08211cd?q=80&w=800&auto=format&fit=crop",
        genre: ["Thriller", "Drama"],
        rating: 8.5,
        status: "Want to Watch",
        year: 2019,
        description: "Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan."
    },
    {
        id: "tt1856101",
        imdbID: "tt1856101",
        title: "Blade Runner 2049",
        poster: "https://images.unsplash.com/photo-1535905557558-afc4877a26fc?q=80&w=800&auto=format&fit=crop",
        genre: ["Sci-Fi", "Noir"],
        rating: 8.0,
        status: "Want to Watch",
        year: 2017,
        description: "Young Blade Runner K's discovery of a long-buried secret leads him to track down former Blade Runner Rick Deckard."
    },
    {
        id: "tt1160419",
        imdbID: "tt1160419",
        title: "Dune",
        poster: "https://images.unsplash.com/photo-1541963463532-d68292c34b19?q=80&w=800&auto=format&fit=crop",
        genre: ["Sci-Fi", "Adventure"],
        rating: 8.2,
        status: "Watched",
        year: 2021,
        description: "Feature adaptation of Frank Herbert's science fiction novel about the son of a noble family entrusted with the protection of the most valuable asset and most vital element in the galaxy.",
        watchedDate: "2024-02-01",
        userRating: 4
    },
];
