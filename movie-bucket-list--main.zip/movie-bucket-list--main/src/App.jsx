import React, { useState, useEffect, Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import Navbar from './components/Navbar';
import SearchModal from './components/SearchModal';
import Modal from './components/Modal';
// Lazy load pages
const Home = lazy(() => import('./pages/Home'));
const BucketList = lazy(() => import('./pages/BucketList'));
const Watched = lazy(() => import('./pages/Watched'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Profile = lazy(() => import('./pages/Profile'));

import { movies as initialMovies } from './data/movies';

import Toast from './components/Toast';

// Wrapper component to handle modal logic at the top level
const AppContent = () => {
  const [movies, setMovies] = useState(() => {
    const saved = localStorage.getItem('movieBucketList');
    if (saved) {
      const parsedMovies = JSON.parse(saved);
      // Data Migration: Update posters for existing default movies to use new Unsplash URLs
      return parsedMovies.map(savedMovie => {
        const freshData = initialMovies.find(m => m.id === savedMovie.id);
        if (freshData) {
          return { ...savedMovie, poster: freshData.poster, description: freshData.description };
        }
        return savedMovie;
      });
    }
    return initialMovies;
  });
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [toast, setToast] = useState({ message: '', type: 'success' }); // Toast state
  const location = useLocation();

  useEffect(() => {
    localStorage.setItem('movieBucketList', JSON.stringify(movies));
  }, [movies]);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
  };

  const handleMovieClick = (movie) => {
    setSelectedMovie(movie);
  };

  const handleCloseModal = () => {
    setSelectedMovie(null);
  };

  const toggleStatus = (id) => {
    setMovies(prevMovies => {
      const exists = prevMovies.find(m => m.id === id);

      if (!exists && selectedMovie && selectedMovie.id === id) {
        // If toggling a movie that isn't in the list, add it as Watched
        const newMovie = { ...selectedMovie, status: 'Watched' };
        showToast(`Added "${newMovie.title}" to Watched`);
        return [newMovie, ...prevMovies];
      }

      const updatedMovies = prevMovies.map(m => {
        if (m.id === id) {
          const newStatus = m.status === 'Watched' ? 'Want to Watch' : 'Watched';
          return { ...m, status: newStatus };
        }
        return m;
      });

      // Optional: Toast for status change? Maybe too noisy.
      return updatedMovies;
    });
  };

  const addMovie = (newMovie) => {
    setMovies(prev => {
      if (prev.some(m => m.id === newMovie.id)) {
        showToast(`"${newMovie.title}" is already in your list`, 'error');
        return prev;
      }
      showToast(`${newMovie.title} added to your Bucket List`);
      return [newMovie, ...prev];
    });
  };

  const removeMovie = (id) => {
    const movieToRemove = movies.find(m => m.id === id);
    setMovies(prev => prev.filter(m => m.id !== id));
    if (movieToRemove) {
      showToast(`${movieToRemove.title} removed from list`, 'success');
    }
    if (selectedMovie && selectedMovie.id === id) {
      setSelectedMovie(null);
    }
  };

  const openSearch = () => setIsSearchOpen(true);

  // Reset scroll on route change
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div className="app">
      <Navbar />

      <AnimatePresence mode="wait">
        <Suspense fallback={
          <div style={{
            height: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: '#141414',
            color: '#E50914'
          }}>
            Loading...
          </div>
        }>
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
                <Home
                  movies={movies}
                  onMovieClick={handleMovieClick}
                  onToggleStatus={toggleStatus}
                  onAddMovie={addMovie}
                />
              </motion.div>
            } />
            <Route path="/list" element={
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}>
                <BucketList
                  movies={movies}
                  onMovieClick={handleMovieClick}
                  onToggleStatus={toggleStatus}
                  onRemove={removeMovie}
                  onOpenSearch={openSearch}
                />
              </motion.div>
            } />
            <Route path="/watched" element={
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}>
                <Watched
                  movies={movies}
                  onMovieClick={handleMovieClick}
                  onToggleStatus={toggleStatus}
                />
              </motion.div>
            } />
            <Route path="/stats" element={
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.3 }}>
                <Dashboard movies={movies} />
              </motion.div>
            } />
            <Route path="/profile" element={
              <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ duration: 0.3 }}>
                <Profile />
              </motion.div>
            } />
          </Routes>
        </Suspense>
      </AnimatePresence>

      <Modal
        movie={selectedMovie}
        isOpen={!!selectedMovie}
        onClose={handleCloseModal}
        onToggleStatus={toggleStatus}
        onAddMovie={addMovie}
        existingMovieIds={movies.map(m => m.id)} // Pass IDs to check existence
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onAddMovie={addMovie}
        existingMovieIds={movies.map(m => m.tmdb_id || m.id)} // Check against tmdb_id if available
        onMovieClick={handleMovieClick}
      />

      <Toast
        message={toast.message}
        type={toast.type}
        onClose={() => setToast({ ...toast, message: '' })}
      />

      <footer style={{
        textAlign: 'center',
        padding: '3rem 2rem',
        color: '#555',
        fontSize: '0.9rem',
        marginTop: 'auto',
        borderTop: '1px solid rgba(255,255,255,0.05)'
      }}>
        <p>© 2024 Movie Bucket List. Designed with Cinema in mind.</p>
      </footer>
    </div>
  );
};

import { SettingsProvider } from './context/SettingsContext';
import { UserProvider } from './context/UserContext';

function App() {
  return (
    <SettingsProvider>
      <UserProvider>
        <Router>
          <AppContent />
        </Router>
      </UserProvider>
    </SettingsProvider>
  );
}

export default App;
