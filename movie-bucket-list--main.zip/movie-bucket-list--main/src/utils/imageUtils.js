// Image utilities
export const FALLBACK_POSTER = "/poster-placeholder.svg"; // Local dark theme fallback

export const handleImageError = (e) => {
    // Prevent infinite loop if fallback fails or is same as current src
    if (e.target.dataset.fallback) return;

    e.target.dataset.fallback = "true";
    e.target.src = FALLBACK_POSTER;
    e.target.onerror = null; // Prevent further error handling for this element
};
