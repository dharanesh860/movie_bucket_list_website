import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Filter, Calendar, Star, Plus } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import SkeletonCard from '../components/SkeletonCard';
import EmptyState from '../components/EmptyState';
import './BucketList.css';

const BucketList = ({ movies, onMovieClick, onToggleStatus, onRemove, onOpenSearch, loading }) => {
    const [selectedGenre, setSelectedGenre] = useState('All');
    const [selectedYear, setSelectedYear] = useState('All');
    const [minRating, setMinRating] = useState('All');

    // Get unique genres and years for filters
    const allGenres = useMemo(() => {
        const genres = new Set(movies.flatMap(m => m.genre));
        return ['All', ...Array.from(genres).sort()];
    }, [movies]);

    const allYears = useMemo(() => {
        const years = new Set(movies.map(m => String(m.year)));
        return ['All', ...Array.from(years).sort((a, b) => b - a)];
    }, [movies]);

    // Filter Logic
    const filteredMovies = useMemo(() => {
        return movies.filter(m => {
            const isWant = m.status === 'Want to Watch';
            const matchGenre = selectedGenre === 'All' || m.genre.includes(selectedGenre);
            const matchYear = selectedYear === 'All' || m.year.toString() === selectedYear;
            const matchRating = minRating === 'All' || m.rating >= parseFloat(minRating);

            return isWant && matchGenre && matchYear && matchRating;
        });
    }, [movies, selectedGenre, selectedYear, minRating]);

    if (loading) {
        return (
            <div className="page container" style={{ paddingTop: '100px', paddingBottom: '4rem' }}>
                <div className="bucket-list-header">
                    <div className="skeleton" style={{ height: '40px', width: '300px', marginBottom: '1rem', borderRadius: '4px' }}></div>
                    <div className="filters-bar" style={{ opacity: 0.5, pointerEvents: 'none' }}>
                        {/* Mock filters for skeleton state */}
                        <div className="filter-group"><Filter size={16} /> Filter</div>
                    </div>
                </div>
                <div className="movie-grid-container">
                    {[...Array(12)].map((_, i) => (
                        <SkeletonCard key={i} />
                    ))}
                </div>
            </div>
        );
    }

    return (
        <div className="page container" style={{ paddingTop: '100px', paddingBottom: '4rem' }}>
            <motion.div
                className="bucket-list-header"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
            >
                <h1 className="bucket-list-title">Movies I Want to Watch</h1>

                <div className="filters-bar">
                    <div className="filter-group">
                        <Filter size={16} />
                        <select
                            className="filter-select"
                            value={selectedGenre}
                            onChange={(e) => setSelectedGenre(e.target.value)}
                        >
                            {allGenres.map(g => (
                                <option key={g} value={g}>{g}</option>
                            ))}
                        </select>
                    </div>

                    <div className="filter-group">
                        <Calendar size={16} />
                        <select
                            className="filter-select"
                            value={selectedYear}
                            onChange={(e) => setSelectedYear(e.target.value)}
                        >
                            <option value="All">Year</option>
                            {allYears.map(y => (
                                <option key={y} value={y}>{y}</option>
                            ))}
                        </select>
                    </div>

                    <div className="filter-group">
                        <Star size={16} />
                        <select
                            className="filter-select"
                            value={minRating}
                            onChange={(e) => setMinRating(e.target.value)}
                        >
                            <option value="All">Rating</option>
                            <option value="9">9+ Stars</option>
                            <option value="8">8+ Stars</option>
                            <option value="7">7+ Stars</option>
                            <option value="6">6+ Stars</option>
                        </select>
                    </div>
                </div>
            </motion.div>

            {filteredMovies.length > 0 ? (
                <motion.div
                    className="movie-grid-container"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                >
                    {filteredMovies.map(movie => (
                        <MovieCard
                            key={movie.id}
                            movie={movie}
                            onClick={onMovieClick}
                            onToggleStatus={onToggleStatus}
                            onRemove={onRemove}
                        />
                    ))}
                </motion.div>
            ) : (
                <div className="empty-wrapper">
                    {movies.filter(m => m.status === 'Want to Watch').length === 0 ? (
                        <EmptyState
                            title="Your bucket list is empty"
                            message="Ready to start your cinematic journey?"
                            actionLabel="Explore Movies"
                            onAction={onOpenSearch}
                        />
                    ) : (
                        <EmptyState
                            title="No movies found"
                            message="Try adjusting your filters to find what you're looking for."
                            actionLabel="Reset Filters"
                            onAction={() => {
                                setSelectedGenre('All');
                                setSelectedYear('All');
                                setMinRating('All');
                            }}
                        />
                    )}
                </div>
            )}

            {/* Floating Action Button */}
            <button className="fab-add" title="Add New Movie" onClick={onOpenSearch}>
                <Plus size={32} />
            </button>
        </div>
    );
};

export default BucketList;
