import React, { useState, useEffect } from 'react';
import Hero from '../components/Hero';
import MovieRow from '../components/MovieRow';
import NetflixSearchResults from '../components/NetflixSearchResults';
import { getTrendingMovies, getPopularMovies, getTopRatedMovies, getUpcomingMovies } from '../services/tmdb';

const Home = ({ movies: userMovies, onMovieClick, onAddMovie }) => {
    const [tmdbData, setTmdbData] = useState({
        trending: [],
        popular: [],
        topRated: [],
        upcoming: []
    });
    const [heroMovie, setHeroMovie] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const fetchAll = async () => {
        setLoading(true);
        setError(null);
        try {
            const [trending, popular, topRated, upcoming] = await Promise.all([
                getTrendingMovies(),
                getPopularMovies(),
                getTopRatedMovies(),
                getUpcomingMovies()
            ]);

            setTmdbData({ trending, popular, topRated, upcoming });

            // Set random hero movie from trending if available, else fallback to user data
            if (trending.length > 0) {
                setHeroMovie(trending[Math.floor(Math.random() * trending.length)]);
            } else if (userMovies.length > 0) {
                setHeroMovie(userMovies[0]);
            }
        } catch (err) {
            console.error("Home fetch failed:", err);
            setError("Failed to load movies. Please check your connection.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAll();
    }, []);

    // Merge TMDB data with user status (check if watched/added)
    const mergeWithUserStatus = (tmdbList) => {
        if (!tmdbList || tmdbList.length === 0) return [];

        return tmdbList.map(tmdbMovie => {
            const userMovie = userMovies.find(m => (m.tmdb_id === tmdbMovie.id) || (m.id === tmdbMovie.id));
            if (userMovie) return userMovie;
            return tmdbMovie;
        });
    };

    const displayTrending = mergeWithUserStatus(tmdbData.trending);
    const displayPopular = mergeWithUserStatus(tmdbData.popular);
    const displayTopRated = mergeWithUserStatus(tmdbData.topRated);
    const displayUpcoming = mergeWithUserStatus(tmdbData.upcoming);

    // Fallback if loading fails or initial load, can show skeletons via loading prop

    return (
        <div className="page page-home">
            <Hero movies={heroMovie ? [heroMovie] : userMovies} loading={loading} />

            <div style={{ marginTop: '-80px', paddingBottom: '4rem', position: 'relative', zIndex: 10 }}>
                <div className="container" style={{ maxWidth: '100%', padding: 0 }}>
                    <NetflixSearchResults
                        onAddMovie={onAddMovie}
                        existingMovieIds={userMovies.map(m => m.id)}
                        onMovieClick={onMovieClick}
                    />

                    <MovieRow
                        title="Trending Now"
                        movies={displayTrending}
                        onMovieClick={onMovieClick}
                        loading={loading}
                        error={error}
                        onRetry={fetchAll}
                    />

                    <MovieRow
                        title="Popular on Bucket List"
                        movies={displayPopular}
                        onMovieClick={onMovieClick}
                        loading={loading}
                    />

                    <MovieRow
                        title="Top Rated Gems"
                        movies={displayTopRated}
                        onMovieClick={onMovieClick}
                        loading={loading}
                    />

                    <MovieRow
                        title="Upcoming Releases"
                        movies={displayUpcoming}
                        onMovieClick={onMovieClick}
                        loading={loading}
                    />
                </div>
            </div>
        </div>
    );
};

export default Home;
