import React, { useState, useRef, useEffect } from 'react';
import { User, Settings, Moon, Globe, Download, RotateCcw, Shield, Sun, Bell, Layout, Edit2, Check, X, Camera, Upload, Loader } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSettings } from '../context/SettingsContext';
import { useUser } from '../context/UserContext';
import { FALLBACK_POSTER } from '../utils/imageUtils';
import './Profile.css';

// Reusable animated toggle component
const AnimatedToggle = ({ isActive, onToggle, activeIcon, inactiveIcon, activeColor = 'var(--accent-red)', inactiveColor = '#333' }) => {
    return (
        <motion.div
            className={`toggle-switch ${isActive ? 'active' : ''}`}
            onClick={onToggle}
            initial={false}
            animate={{ backgroundColor: isActive ? activeColor : inactiveColor }}
            whileTap={{ scale: 0.9 }}
            style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', padding: '2px' }}
        >
            <motion.div
                className="toggle-thumb"
                layout
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
                style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: 'white',
                    width: '20px',
                    height: '20px',
                    borderRadius: '50%'
                }}
            >
                {isActive ? activeIcon : inactiveIcon}
            </motion.div>
        </motion.div>
    );
};

// Interactive Button with micro-interactions
const InteractiveButton = ({ children, onClick, className, disabled, variant = 'normal', style }) => {
    const [isPressed, setIsPressed] = useState(false);

    const handleClick = (e) => {
        if (disabled) return;
        setIsPressed(true);
        // Brief visual debounce
        setTimeout(() => setIsPressed(false), 200);
        onClick && onClick(e);
    };

    return (
        <motion.button
            className={`${className} ${isPressed ? 'pressed' : ''}`}
            onClick={handleClick}
            disabled={disabled}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
            style={style}
        >
            {children}
        </motion.button>
    );
};

const ProfileSkeleton = () => (
    <div className="page container" style={{ paddingTop: '100px', paddingBottom: '4rem', maxWidth: '800px' }}>
        <div className="profile-card skeleton-card">
            <div className="profile-header">
                <div className="skeleton" style={{ width: '80px', height: '80px', borderRadius: '50%', marginBottom: '1rem' }}></div>
                <div className="skeleton" style={{ width: '200px', height: '32px', marginBottom: '0.5rem', borderRadius: '4px' }}></div>
                <div className="skeleton" style={{ width: '150px', height: '16px', marginBottom: '1.5rem', borderRadius: '4px' }}></div>
                <div className="skeleton" style={{ width: '140px', height: '36px', borderRadius: '4px' }}></div>
            </div>

            <div className="profile-stats">
                {[...Array(3)].map((_, i) => (
                    <div key={i} className="stat-bubble">
                        <div className="skeleton" style={{ width: '40px', height: '20px', marginBottom: '4px', borderRadius: '4px' }}></div>
                        <div className="skeleton" style={{ width: '60px', height: '12px', borderRadius: '4px' }}></div>
                    </div>
                ))}
            </div>

            <div className="settings-section">
                <div className="section-title">
                    <div className="skeleton" style={{ width: '120px', height: '24px', borderRadius: '4px' }}></div>
                </div>
                {[...Array(4)].map((_, i) => (
                    <div key={i} className="setting-item">
                        <div className="setting-info" style={{ flex: 1 }}>
                            <div className="skeleton" style={{ width: '100px', height: '20px', marginBottom: '6px', borderRadius: '4px' }}></div>
                            <div className="skeleton" style={{ width: '180px', height: '14px', borderRadius: '4px' }}></div>
                        </div>
                        <div className="skeleton" style={{ width: '40px', height: '24px', borderRadius: '12px' }}></div>
                    </div>
                ))}
            </div>
        </div>
    </div>
);

const Profile = () => {
    const { settings, toggleSetting, isDark } = useSettings();
    const { user, updateName, updateAvatar } = useUser();

    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const timer = setTimeout(() => setLoading(false), 800);
        return () => clearTimeout(timer);
    }, []);

    const [isExported, setIsExported] = React.useState(false);

    const [isEditing, setIsEditing] = useState(false);
    const [saveStatus, setSaveStatus] = useState('idle'); // 'idle', 'saving', 'success'
    const [tempName, setTempName] = useState('');

    // Avatar Menu
    const [isAvatarMenuOpen, setIsAvatarMenuOpen] = useState(false);
    const fileInputRef = useRef(null);

    const startEditing = () => {
        setTempName(user.name);
        setSaveStatus('idle');
        setIsEditing(true);
    };

    const saveProfile = () => {
        if (!tempName.trim()) return;

        setSaveStatus('saving');

        // Simulate network/processing delay for premium feel
        setTimeout(() => {
            updateName(tempName);
            setSaveStatus('success');

            // Close after showing success state
            setTimeout(() => {
                setIsEditing(false);
                setSaveStatus('idle');
                setIsAvatarMenuOpen(false);
            }, 1000);
        }, 800);
    };

    const cancelEditing = () => {
        setIsEditing(false);
        setIsAvatarMenuOpen(false);
        setSaveStatus('idle');
    };

    const handleAvatarUpdate = (newAvatar) => {
        updateAvatar(newAvatar);
        setIsAvatarMenuOpen(false);
    };

    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 5000000) {
                alert("Image size should be less than 5MB");
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => {
                handleAvatarUpdate(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const [isFixing, setIsFixing] = useState(false);

    const fixBrokenPosters = async () => {
        if (!window.confirm("This will verify all movie posters and replace broken ones with a default image. This may take a moment. Continue?")) {
            return;
        }

        setIsFixing(true);
        try {
            const saved = localStorage.getItem('movieBucketList');
            if (!saved) {
                setIsFixing(false);
                return;
            }

            const movies = JSON.parse(saved);
            let updatedCount = 0;

            const checkImage = (url) => {
                return new Promise((resolve) => {
                    const img = new Image();
                    img.onload = () => resolve(true);
                    img.onerror = () => resolve(false);
                    img.src = url;
                });
            };

            const updatedMovies = await Promise.all(movies.map(async (movie) => {
                // Skip if already fallback or valid internal URL (unlikely but safe)
                if (movie.poster === FALLBACK_POSTER) return movie;

                // Check if image loads
                const isValid = await checkImage(movie.poster);
                if (!isValid) {
                    updatedCount++;
                    return { ...movie, poster: FALLBACK_POSTER };
                }
                return movie;
            }));

            if (updatedCount > 0) {
                localStorage.setItem('movieBucketList', JSON.stringify(updatedMovies));
                alert(`Fixed ${updatedCount} broken posters! Reloading...`);
                window.location.reload();
            } else {
                alert("No broken posters found!");
            }
        } catch (error) {
            if (import.meta.env.DEV) console.error("Fix failed:", error);
            alert("Something went wrong while fixing posters.");
        } finally {
            setIsFixing(false);
        }
    };

    const handleExport = () => {
        try {
            const data = localStorage.getItem('movieBucketList');
            if (!data) return;

            const blob = new Blob([data], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'movie-bucket-list.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            setIsExported(true);
            setTimeout(() => setIsExported(false), 2000);
        } catch (error) {
            if (import.meta.env.DEV) console.error("Export failed:", error);
        }
    };

    const avatarPresets = [
        'linear-gradient(135deg, #E50914, #B81D24)',
        'linear-gradient(135deg, #0072d6, #005bb5)',
        'linear-gradient(135deg, #46d369, #36a852)',
        'linear-gradient(135deg, #f5bc42, #d9a536)',
        'linear-gradient(135deg, #8e44ad, #732d91)',
    ];

    if (loading) {
        return <ProfileSkeleton />;
    }

    return (
        <div className="page container" style={{ paddingTop: '100px', paddingBottom: '4rem', maxWidth: '800px' }}>
            <motion.div
                className="profile-card"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
            >
                {/* Header */}
                <div className={`profile-header ${isEditing ? 'editing-mode' : ''}`}>
                    <div
                        className={`avatar-container ${isEditing ? 'interactive' : ''}`}
                        onClick={() => isEditing && setIsAvatarMenuOpen(!isAvatarMenuOpen)}
                    >
                        {user.avatar ? (
                            user.avatar.startsWith('data:') ? (
                                <img src={user.avatar} alt="Profile" className="avatar-image" />
                            ) : (
                                <div className="avatar-preset" style={{ background: user.avatar }}>
                                    <User size={64} color="white" />
                                </div>
                            )
                        ) : (
                            <User size={64} className="text-gray-300" />
                        )}

                        {isEditing && (
                            <motion.div
                                className="avatar-overlay"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                            >
                                <Camera size={24} />
                                <span>Change</span>
                            </motion.div>
                        )}

                        <input
                            type="file"
                            ref={fileInputRef}
                            style={{ display: 'none' }}
                            accept="image/*"
                            onChange={handleFileUpload}
                        />
                    </div>

                    <AnimatePresence>
                        {isAvatarMenuOpen && isEditing && (
                            <motion.div
                                className="avatar-menu"
                                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                                animate={{ opacity: 1, y: 0, scale: 1 }}
                                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                                transition={{ duration: 0.2 }}
                            >
                                <div className="menu-option upload" onClick={() => fileInputRef.current?.click()}>
                                    <Upload size={16} /> Upload Photo
                                </div>
                                <div className="menu-divider"></div>
                                <div className="presets-grid">
                                    <div
                                        className="preset-item default"
                                        onClick={() => handleAvatarUpdate(null)}
                                        title="Default"
                                    >
                                        <User size={20} />
                                    </div>
                                    {avatarPresets.map((preset, i) => (
                                        <div
                                            key={i}
                                            className="preset-item"
                                            style={{ background: preset }}
                                            onClick={() => handleAvatarUpdate(preset)}
                                        />
                                    ))}
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>

                    {isEditing ? (
                        <div className="name-edit-wrapper">
                            <input
                                type="text"
                                value={tempName}
                                onChange={(e) => setTempName(e.target.value)}
                                className="profile-name-input"
                                autoFocus
                                placeholder="Enter your name"
                                style={{ borderColor: !tempName.trim() ? '#ff4d4d' : undefined }}
                            />
                        </div>
                    ) : (
                        <h1 className="profile-name">{user.name}</h1>
                    )}

                    <p className="profile-tagline">Premium Member • Since 2024</p>

                    <div className="profile-actions" style={{ marginTop: '1rem', display: 'flex', gap: '1rem', height: '40px' }}>
                        <AnimatePresence mode="wait">
                            {isEditing ? (
                                <motion.div
                                    key="editing-actions"
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.9 }}
                                    style={{ display: 'flex', gap: '1rem' }}
                                >
                                    <InteractiveButton
                                        className="btn-small btn-success"
                                        onClick={saveProfile}
                                        disabled={saveStatus !== 'idle' || !tempName.trim()}
                                        style={{ minWidth: '140px', justifyContent: 'center' }}
                                    >
                                        {saveStatus === 'idle' && <><Check size={16} /> Save Changes</>}
                                        {saveStatus === 'saving' && (
                                            <motion.div
                                                animate={{ rotate: 360 }}
                                                transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                                                style={{ display: 'flex' }}
                                            >
                                                <Loader size={16} />
                                            </motion.div>
                                        )}
                                        {saveStatus === 'success' && <><Check size={16} /> Saved!</>}
                                    </InteractiveButton>
                                    <InteractiveButton
                                        className="btn-small btn-danger"
                                        onClick={cancelEditing}
                                        disabled={saveStatus !== 'idle'}
                                    >
                                        <X size={16} /> Cancel
                                    </InteractiveButton>
                                </motion.div>
                            ) : (
                                <motion.div
                                    key="edit-btn"
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                >
                                    <InteractiveButton className="btn-small" onClick={startEditing} style={{ border: '1px solid rgba(255,255,255,0.3)' }}>
                                        <Edit2 size={16} /> Edit Profile
                                    </InteractiveButton>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>
                </div>

                {/* Stats Row */}
                <div className="profile-stats">
                    <div className="stat-bubble">
                        <span className="value">142h</span>
                        <span className="label">Watch Time</span>
                    </div>
                    <div className="stat-bubble">
                        <span className="value">
                            <div className="genres-list">
                                {user.genres?.map(g => (
                                    <span key={g.name} className="genre-badge">{g.name}</span>
                                )) || <span className="genre-badge">None</span>}
                            </div>
                        </span>
                        <span className="label">Favorite Genres</span>
                    </div>
                    <div className="stat-bubble">
                        <span className="value">Pro</span>
                        <span className="label">Plan</span>
                    </div>
                </div>

                {/* Settings Section */}
                <div className="settings-section">
                    <div className="section-title"><Settings size={18} /> App Settings</div>

                    {/* Dark Mode */}
                    <div className="setting-item">
                        <div className="setting-info">
                            <h4>{isDark ? 'Dark Mode' : 'Light Mode'}</h4>
                            <p>{isDark ? 'Cinematic dark theme active' : 'Bright light theme active'}</p>
                        </div>
                        <AnimatedToggle
                            isActive={isDark}
                            onToggle={() => toggleSetting('theme')}
                            activeIcon={<Moon size={12} color="#E50914" />}
                            inactiveIcon={<Sun size={12} color="#F59E0B" />}
                        />
                    </div>

                    {/* Notifications */}
                    <div className="setting-item">
                        <div className="setting-info">
                            <h4>Notifications</h4>
                            <p>Receive updates about movies and lists</p>
                        </div>
                        <AnimatedToggle
                            isActive={settings.notifications}
                            onToggle={() => toggleSetting('notifications')}
                            activeIcon={<Bell size={12} color="#E50914" />}
                            inactiveIcon={<Bell size={12} color="#666" />}
                        />
                    </div>

                    {/* Compact Mode */}
                    <div className="setting-item">
                        <div className="setting-info">
                            <h4>Compact Layout</h4>
                            <p>Dense interface for more content</p>
                        </div>
                        <AnimatedToggle
                            isActive={settings.compactMode}
                            onToggle={() => toggleSetting('compactMode')}
                            activeIcon={<Layout size={12} color="#E50914" />}
                            inactiveIcon={<Layout size={12} color="#666" />}
                        />
                    </div>

                    {/* Data Export */}
                    <div className="setting-item">
                        <div className="setting-info">
                            <h4>Data Export</h4>
                            <p>Download your movie list as JSON</p>
                        </div>
                        <InteractiveButton
                            className={`btn-small ${isExported ? 'btn-success' : ''}`}
                            onClick={handleExport}
                            disabled={isExported}
                        >
                            {isExported ? (
                                <><Globe size={14} /> Exported!</>
                            ) : (
                                <><Download size={14} /> Export Data</>
                            )}
                        </InteractiveButton>
                    </div>

                    <div className="section-title" style={{ marginTop: '1rem', color: '#ff4d4d' }}>
                        <Shield size={18} /> Danger Zone
                    </div>

                    <div className="setting-item" style={{ borderColor: 'rgba(255, 77, 77, 0.2)' }}>
                        <div className="setting-info">
                            <h4>Fix Broken Posters</h4>
                            <p>Scan and repair expired image links</p>
                        </div>
                        <InteractiveButton
                            className="btn-small"
                            onClick={fixBrokenPosters}
                            disabled={isFixing}
                            style={{ borderColor: 'rgba(255, 255, 255, 0.2)' }}
                        >
                            {isFixing ? (
                                <><Loader size={14} className="spin" /> Scanning...</>
                            ) : (
                                <><RotateCcw size={14} /> Scan & Fix</>
                            )}
                        </InteractiveButton>
                    </div>

                    <div className="setting-item" style={{ borderColor: 'rgba(255, 77, 77, 0.2)' }}>
                        <div className="setting-info">
                            <h4>Reset Bucket List</h4>
                            <p>Clear all 'Want to Watch' movies</p>
                        </div>
                        <InteractiveButton
                            className="btn-small btn-danger"
                            onClick={() => {
                                if (window.confirm("Are you sure? This cannot be undone.")) {
                                    alert("List reset functionality is protected in this demo.");
                                }
                            }}
                        >
                            <RotateCcw size={14} /> Reset List
                        </InteractiveButton>
                    </div>
                </div>

            </motion.div>
        </div>
    );
};

export default Profile;
