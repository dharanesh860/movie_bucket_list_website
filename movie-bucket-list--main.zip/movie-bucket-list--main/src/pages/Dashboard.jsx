import React from 'react';
import StatsDashboard from '../components/StatsDashboard';
import { motion } from 'framer-motion';

const Dashboard = ({ movies }) => {
    return (
        <div className="page container" style={{ paddingTop: '100px', paddingBottom: '4rem' }}>
            <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                style={{ fontSize: '2.5rem', marginBottom: '2rem', fontWeight: 800 }}
            >
                My Stats
            </motion.h1>

            <StatsDashboard movies={movies} loading={false} />

            {/* Could add more charts here in the future */}
        </div>
    );
};

export default Dashboard;
