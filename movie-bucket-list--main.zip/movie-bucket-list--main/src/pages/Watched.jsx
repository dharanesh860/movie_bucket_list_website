import React from 'react';
import { motion } from 'framer-motion';
import WatchedCard from '../components/WatchedCard';
import SkeletonCard from '../components/SkeletonCard';
import EmptyState from '../components/EmptyState';
import './Watched.css';

const Watched = ({ movies, onMovieClick, loading }) => {
    const watched = movies.filter(m => m.status === 'Watched');

    const handleReWatch = (id) => {
        // Trigger generic click which usually opens modal
        const movie = movies.find(m => m.id === id);
        if (movie && onMovieClick) onMovieClick(movie);
    };

    const handleAddNote = (movie) => {
        if (onMovieClick) onMovieClick(movie);
    };

    if (loading) {
        return (
            <div className="page container" style={{ paddingTop: '100px', paddingBottom: '4rem' }}>
                <div style={{ marginBottom: '2rem' }}>
                    <div className="skeleton" style={{ height: '40px', width: '250px', marginBottom: '0.5rem', borderRadius: '4px' }}></div>
                    <div className="skeleton" style={{ height: '20px', width: '150px', borderRadius: '4px' }}></div>
                </div>
                <div className="watched-grid-container">
                    {[...Array(8)].map((_, i) => (
                        <SkeletonCard key={i} detailed={true} />
                    ))}
                </div>
            </div>
        );
    }

    return (
        <div className="page container" style={{ paddingTop: '100px', paddingBottom: '4rem' }}>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                style={{ marginBottom: '2rem' }}
            >
                <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '0.5rem' }}>Watched Movies</h1>
                <p style={{ color: 'var(--text-secondary)' }}>Your cinematic journey achievements</p>
            </motion.div>

            {watched.length > 0 ? (
                <div className="watched-grid-container">
                    {watched.map(movie => (
                        <WatchedCard
                            key={movie.id}
                            movie={movie}
                            onReWatch={handleReWatch}
                            onAddNote={handleAddNote}
                        />
                    ))}
                </div>
            ) : (
                <EmptyState
                    title="No watched movies yet"
                    message="Every legend has a beginning. Start yours by marking movies as watched."
                    actionLabel="Go to Bucket List"
                    onAction={() => window.location.href = '/bucket-list'}
                />
            )}
        </div>
    );
};

export default Watched;
