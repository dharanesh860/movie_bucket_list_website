const API_KEY = import.meta.env.VITE_TMDB_API_KEY;
const BASE_URL = 'https://api.themoviedb.org/3';
const IMAGE_BASE_URL = 'https://image.tmdb.org/t/p/w500';
const BACKDROP_BASE_URL = 'https://image.tmdb.org/t/p/original';

// Genre ID to Name mapping (simplified)
const genreMap = {
    28: "Action", 12: "Adventure", 16: "Animation", 35: "Comedy",
    80: "Crime", 99: "Documentary", 18: "Drama", 10751: "Family",
    14: "Fantasy", 36: "History", 27: "Horror", 10402: "Music",
    9648: "Mystery", 10749: "Romance", 878: "Sci-Fi", 10770: "TV Movie",
    53: "Thriller", 10752: "War", 37: "Western"
};

const mapGenres = (genreIds) => {
    if (!genreIds) return [];
    return genreIds.map(id => genreMap[id]).filter(Boolean).slice(0, 3);
};

export const getImageUrl = (path) => {
    return path ? `${IMAGE_BASE_URL}${path}` : 'https://placehold.co/500x750?text=No+Poster';
};

export const getBackdropUrl = (path) => {
    return path ? `${BACKDROP_BASE_URL}${path}` : null;
};

// Transform TMDB result to our App's Movie format
const transformMovie = (tmdbMovie) => {
    return {
        id: tmdbMovie.id, // Keep TMDB ID
        title: tmdbMovie.title,
        poster: getImageUrl(tmdbMovie.poster_path),
        backdrop: getBackdropUrl(tmdbMovie.backdrop_path),
        genre: tmdbMovie.genres ? tmdbMovie.genres.map(g => g.name).slice(0, 3) : mapGenres(tmdbMovie.genre_ids),
        rating: tmdbMovie.vote_average ? Number(tmdbMovie.vote_average.toFixed(1)) : 0,
        status: 'Want to Watch', // Default status for new adds
        year: tmdbMovie.release_date ? new Date(tmdbMovie.release_date).getFullYear() : 'N/A',
        description: tmdbMovie.overview,
        tmdb_id: tmdbMovie.id,
        tagline: tmdbMovie.tagline || '',
        runtime: tmdbMovie.runtime || 0
    };
};

const fetchFromTMDB = async (endpoint) => {
    if (!API_KEY) return [];
    try {
        const response = await fetch(`${BASE_URL}${endpoint}?api_key=${API_KEY}`);
        if (!response.ok) throw new Error(`API Error: ${response.status}`);
        const data = await response.json();
        return data.results.map(transformMovie);
    } catch (error) {
        if (import.meta.env.DEV) console.error(`Fetch failed for ${endpoint}:`, error);
        return [];
    }
};

export const searchMovies = async (query) => {
    if (!query) return [];
    if (!API_KEY) {
        if (import.meta.env.DEV) console.warn("TMDB API Key missing");
        return [];
    }

    try {
        const response = await fetch(`${BASE_URL}/search/movie?api_key=${API_KEY}&query=${encodeURIComponent(query)}&include_adult=false`);
        if (!response.ok) throw new Error('API Error');
        const data = await response.json();
        return data.results.map(transformMovie);
    } catch (error) {
        if (import.meta.env.DEV) console.error("Search failed:", error);
        return [];
    }
};

export const getMovieDetails = async (id) => {
    if (!API_KEY) return null;
    try {
        const response = await fetch(`${BASE_URL}/movie/${id}?api_key=${API_KEY}`);
        if (!response.ok) throw new Error('API Error');
        const data = await response.json();
        return transformMovie(data);
    } catch (error) {
        if (import.meta.env.DEV) console.error("Get details failed:", error);
        return null;
    }
};

export const getTrendingMovies = () => fetchFromTMDB('/trending/movie/week');
export const getPopularMovies = () => fetchFromTMDB('/movie/popular');
export const getTopRatedMovies = () => fetchFromTMDB('/movie/top_rated');
export const getUpcomingMovies = () => fetchFromTMDB('/movie/upcoming');
