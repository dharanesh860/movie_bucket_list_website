const API_KEY = import.meta.env.VITE_OMDB_API_KEY;
const BASE_URL = 'https://www.omdbapi.com';

let apiKeyWarningLogged = false;

export const searchOmdbMovies = async (query) => {
    if (!API_KEY) {
        if (!apiKeyWarningLogged && import.meta.env.DEV) {
            console.warn("OMDb API Key is missing in .env");
            apiKeyWarningLogged = true;
        }
        return [];
    }

    try {
        const response = await fetch(`${BASE_URL}/?apikey=${API_KEY}&s=${encodeURIComponent(query)}&type=movie`);
        const data = await response.json();

        if (data.Response === "True") {
            return data.Search.map(movie => ({
                id: movie.imdbID,
                imdbID: movie.imdbID,
                title: movie.Title,
                poster: movie.Poster && movie.Poster !== "N/A" ? movie.Poster : "https://placehold.co/300x450?text=No+Poster",
                year: movie.Year,
                type: movie.Type,
                status: 'Want to Watch',
                rating: 'N/A',
                genre: [],
                description: 'No description available.'
            }));
        }
        return [];
    } catch (error) {
        if (import.meta.env.DEV) console.error("OMDb Search Error:", error);
        return [];
    }
};

export const getOmdbMovieDetails = async (id) => {
    if (!API_KEY) return null;
    try {
        const response = await fetch(`${BASE_URL}/?apikey=${API_KEY}&i=${id}&plot=full`);
        const data = await response.json();

        if (data.Response === "True") {
            return {
                id: data.imdbID,
                imdbID: data.imdbID,
                title: data.Title,
                poster: data.Poster !== "N/A" ? data.Poster : "https://placehold.co/300x450?text=No+Poster",
                year: data.Year,
                rating: data.imdbRating,
                runtime: parseInt(data.Runtime) || 0, // Convert "148 min" to number
                genre: data.Genre ? data.Genre.split(', ') : [],
                description: data.Plot,
                director: data.Director,
                actors: data.Actors,
                status: 'Want to Watch'
            };
        }
        return null;
    } catch (error) {
        if (import.meta.env.DEV) console.error("OMDb Details Error:", error);
        return null;
    }
};
